
import java.util.Scanner;
import java.util.Random;

public class Test {
    public static void ToChucThi(Student students[]) {
        Random random = new Random();
        for (int i = 0; i < students.length; i++) {
            students[i].lamBaiThi();
        }      
        for (int i = 0; i < students.length; i++) {
            int mthd = random.nextInt(3);
            if (mthd == 0) continue;
            else if (mthd == 1) {
                students[i].lamBaiThi(42);
            } 
            else {
                int bankeben = random.nextInt(2) - 1;
                try {
                    students[i].lamBaiThi(bankeben);
                } 
                catch (Exception e) {
                    continue;
                }
            }
            students[i].lamBaiThi();
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Nhap so luong sinh vien: ");
        int n = scanner.nextInt();
        Student students[] = new Student[n];
        for (int i = 0; i < n; i++) {
            System.out.println("Nhap sinh vien thu: " + (i + 1));
            System.out.print("Nhap ten: ");
            String name = scanner.next();
            System.out.print("Nhap nam sinh: ");
            int year = scanner.nextInt();
            students[i] = new Student(name, year);
        }
        scanner.close();
        System.out.println("Dang to chuc cho cac sinh vien lam bai thi...");
        ToChucThi(students);
        for (int i = 0; i < n; i++) {
            System.out.print("Diem sinh vien " + students[i].getName() + ": ");
            System.out.println(students[i].getScore());
        }
    }
}