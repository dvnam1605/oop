import java.util.Random;

public class Student {
    private String name ;
    private int year ;
    private int score = 0;
    private Random random = new Random();
    static private int soSinhVienDaTao = 0;
    static private long tongDiemThiTatCaSV = 0;
    public Student() {
        soSinhVienDaTao++;
    }
    public Student(String name, int year) {
        this.name = name;
        this.year = year;
        this.score = 0;
        soSinhVienDaTao++;
    }
    public String getName() {
        return name;
    }
    public int getYear() {
        return year;
    }
    public int getScore() {
        return score;
    }
    public void lamBaiThi() {
    	int diemcu = this.score;
        this.score = random.nextInt(10);
        tongDiemThiTatCaSV = getTongDiemThiTatCaSV() + this.score - diemcu;
    }
    public void lamBaiThi(long seed) {
    	int diemcu = this.score;
        random.setSeed(seed);
        this.score = random.nextInt(10);
        tongDiemThiTatCaSV = getTongDiemThiTatCaSV() + this.score - diemcu;
    }
    public void lamBaiThi(Student bankeben) {
    	int diemcu = this.score;
        lamBaiThi();
        this.score /= 2;
        this.score += bankeben.getScore() / 2;
        tongDiemThiTatCaSV = getTongDiemThiTatCaSV() + this.score - diemcu;
    }
    public void inDiemThi() {
        System.out.println("Ten sinh vien: " + getName());
        System.out.println("Nam sinh: " + getYear());
        System.out.println("Diem: " + getScore());
    }
	public static int getSoSinhVienDaTao() {
		return soSinhVienDaTao;
	}
	public static void setSoSinhVienDaTao(int soSinhVienDaTao) {
		Student.soSinhVienDaTao = soSinhVienDaTao;
	}
	static public int TongDiemThi(Student... args) {
		int sum = 0;
		int n = args.length;
		for(int i = 0; i < n; i++) {
			sum+=args[i].score;
		}
		return sum;
	}
	public static long getTongDiemThiTatCaSV() {
		return tongDiemThiTatCaSV;
	}

}