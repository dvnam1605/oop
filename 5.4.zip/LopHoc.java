
import java.util.Random;
import java.util.Scanner;

public class LopHoc {
    private static int soLuongSinhVien;
    private static Student students[];
    public void setsoLuongSinhVien(int soLuongSinhVien) {
        LopHoc.soLuongSinhVien = soLuongSinhVien;
        LopHoc.students = new Student[soLuongSinhVien];
    }
    public static Student[] getStudents() {
        return students;
    }
    public LopHoc() {
        System.out.print("Nhap so luong sinh vien: ");
        Scanner sc = new Scanner(System.in);
        setsoLuongSinhVien(sc.nextInt());
        for (int i = 0; i < soLuongSinhVien; i++) {
            System.out.println("Nhap sinh vien thu: " + (i + 1));
            System.out.print("Nhap ten: ");
            String name = sc.next();
            System.out.print("Nhap nam sinh: ");
            int year = sc.nextInt();
            students[i] = new Student(name, year);
        }
        sc.close();
    }
    public LopHoc(int soLuongSinhVien) {
        setsoLuongSinhVien(soLuongSinhVien);
        for (int i = 0; i < soLuongSinhVien; i++) {
            Random random = new Random();
            int nameLength = random.nextInt(30) + 1;
            String name = "";
            for (int j = 0; j < nameLength; j++) {
                name += (char) (random.nextInt(26) + 'a');
            }
            students[i] = new Student(name, random.nextInt(20) + 1990);
        }
    }
    public void inDanhSachTheoDiem() {
        for (int i = 0; i < soLuongSinhVien - 1; i++) {
            for (int j = i + 1; j < soLuongSinhVien; j++) {
                if (students[i].getScore() < students[j].getScore()) {
                    Student temp = students[i];
                    students[i] = students[j];
                    students[j] = temp;
                }
            }
        }
        for (int i = 0; i < soLuongSinhVien; i++) {
            System.out.printf("%-30s %d %d\n", students[i].getName(), students[i].getScore(), students[i].getYear());
        }
    }
    public void inDanhSachTheoNamSinh() {
        for (int i = 0; i < soLuongSinhVien - 1; i++) {
            for (int j = i + 1; j < soLuongSinhVien; j++) {
                if (students[i].getYear() < students[j].getYear()) {
                    Student temp = students[i];
                    students[i] = students[j];
                    students[j] = temp;
                }
            }
        }
        for (int i = 0; i < soLuongSinhVien; i++) {
            System.out.printf("%-30s %d %d\n", students[i].getName(), students[i].getScore(), students[i].getYear());
        }
    }
    public static void main(String[] args) {
        LopHoc lopHoc = new LopHoc(10);
        Test.ToChucThi(LopHoc.getStudents());
        System.out.println("Danh sach theo diem: ");
        lopHoc.inDanhSachTheoDiem();
        System.err.println("---------------------------------");
        System.out.println("Danh sach theo nam sinh: ");
        lopHoc.inDanhSachTheoNamSinh();
    }
}
